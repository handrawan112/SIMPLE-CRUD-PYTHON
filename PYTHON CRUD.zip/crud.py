#!/usr/bin/env python
from buatTabel import BuatTabel
from hapusTabel import HapusTabel
from update import Perbarui
from delete import Hapus
from view import Tampil
from add import Tambah
from hkhhapus import Hdhandrawan

def  menu(pilih):
          if pilih==1:
              print "Membuat Tabel di database data".upper()
              BuatTabel()
          elif pilih==2:
              print "Menghapus Tabel di database data".upper()
              HapusTabel()
          elif pilih==3:
              print "Menampilkan Data Tabel di Terminal".upper()
              Tampil()
          elif pilih==4:
              print "Menambahkan Data di Tabel".upper()
              Tambah()
          elif pilih==5:
              print "Menghapus Data di Tabel".upper()
              Hapus()
          elif pilih==6:
              print "Memperbarui Data di Tabel".upper()
              Perbarui()
          elif pilih==7:
              print "Hapus Data di Tabel handrawan".upper()
              Hdhandrawan()

def  menuUlang():
           print " "
           print " ****  ****   *  *  ****"
           print "**     *   *  *  *  *   *"
           print "**     ****   *  *  *   *"
           print "**     *  *   *  *  *   *"
           print " ****  *   *  ****  ****"
           print "@PYTHON PROGRAMMING LANGUAGE"
           print "@Created by Handrawan"
           print " "
           print "[*] 1.Buat Tabel Database \t"
           print "[*] 2.Hapus Tabel Database \t"
           print "[*] 3.Tampilkan data di Terminal \t "
           print "[*] 4.Tambah data di Tabel\t"
           print "[*] 5.Hapus data di tabel\t"
           print "[*] 6.Perbarui data di tabel\t"
           print "[*] 7.Hapus data di tabel handrawan\t"
           print "[*] 0.Untuk mengakhiri proses\t"
           print " "
           pilih=int(input("Silakan pilih nomor menu :\t"))
           if pilih==0:
               print "Proses terhenti"
           else:
               menu(pilih)
               menuUlang()

def  masuk():
          print "\n\t    LOGIN DATABASE\t\t\n"
          user=["handrawan","20111999"]
          userX,userY=user[0],user[1]
          if userX in user and userY in user:
             print "Login Berhasil"
             menuUlang()
          else:
             print "Login Gagal"
             if userX in user:
                 if userY in user:
                    print "Login berhasil"
                 else:
                    print "Password salah"
             else:
                print "Username Salah"

masuk()


