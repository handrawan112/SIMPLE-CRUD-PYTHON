#!/usr/bin/env python
class Tampil:
    def __init__(self):
           import sqlite3
           con=sqlite3.connect("data.db")
           db=con.cursor()
           namaDB=raw_input("Nama tabel database : \t")
           print "DAFTAR TABEL ",namaDB
           i=0
           for row in db.execute("SELECT*FROM "+namaDB):
                 i+=1
                 print i,row
           con.close()

