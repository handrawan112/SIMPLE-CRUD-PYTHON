#!/usr/bin/env python
class HapusTabel:
    def  __init__(self):
           import sqlite3
           con=sqlite3.connect("data.db")
           db=con.cursor()
           namaT=raw_input("Masukan nama tabel yang ingin dihapus : \n")
           cekDb=db.execute("DELETE FROM handrawan WHERE namaTabel="+"'"+str(namaT)+"'")
           if cekDb:
              cekT=db.execute("DROP TABLE "+namaT)
              if cekT:
                 print "Tabel ",namaT, "Sukses di hapus"
              else:
                 print "Tabel ",namaT, "Gagal di hapus"
           else:
              print "Tabel ",namaT," Gagal dihapus"
           con.commit()
           con.close()

