#!/usr/bin/env python
import sqlite3
class Hdhandrawan:
   def  __init__(self):
           con=sqlite3.connect("data.db")
           db=con.cursor()
           inp=raw_input("Masukan nama yang ada di tabel handrawan\n")
           v=db.execute("DELETE FROM handrawan WHERE namaTabel="+"'"+inp+"'")
           if v:
              print "Sukses di hapus ",inp," dari tabel handrawan"
           else:
              print "Gagal dihapus ",inp," dari tabel handrawan"
           con.commit()
           con.close()
