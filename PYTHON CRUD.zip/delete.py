#!/usr/bin/env python
class Hapus:
    def  __init__(self):
           import sqlite3
           con=sqlite3.connect("data.db")
           db=con.cursor()
           namaTabel=raw_input("Nama tabel database \t")
           namaBarangH=raw_input("Nama barang yang dihapus  :  ")
           cekDb=db.execute("DELETE FROM "+namaTabel+" WHERE namaBarang='"+namaBarangH+"'")
           if cekDb:
              print "Berhasil dihapus"
           else:
              print "Gagal dihapus"
           con.commit()
           con.close()

