#!/usr/bin/env python
class BuatTabel:
  def  __init__(self):
        import sqlite3
        con=sqlite3.connect("data.db")
        db=con.cursor()
        namaT=raw_input("Nama buat tabel database :\t")
        sb=[]
        sa=[]
        for i in range(20):
              sa.append(i)
        def nname(x):
             b=raw_input("Masukan data :\t")
             if len(sb)==20:
                print "Melebihi batas "      
             else:
                if b=="$":
                   print "Proses dihentikan"
                else:
                   sb.append(b)
                   nname(b)

        bx=raw_input("Masukan data :\t")
        sb.append(bx)
        nname(bx)
        if len(sb)==0:
           print "Maaf, Nilai tidak ada !! Tabel Gagal dibuat"
        else:
           cekDb=db.execute("INSERT INTO handrawan VALUES"+"('"+str(namaT)+"')")
           if cekDb:
             print "Tabel ",namaT," Berhasil dibuat"
             nil=len(sb)
             print nil," Data dikumpulkan"
             if nil==1:
                 db.execute("CREATE TABLE "+namaT+"(a text)")
                 a=sb[0]
                 db.execute("INSERT INTO "+namaT+" VALUES "+"('"+a+"')")
                 print "1 kolom tabel"
             elif nil==2:
                 db.execute("CREATE TABLE "+namaT+"(a text,b text)")
                 a,b=sb[0],sb[1]
                 db.execute("INSERT INTO "+namaT+" VALUES "+"('"+a+"','"+b+"')")
                 print "2 kolom tabel"
             elif nil==3:
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text)")
                 a,b,c=sb[0],sb[1],sb[2]
                 db.execute("INSERT INTO "+namaT+" VALUES "+"('"+a+"','"+b+"','"+c+"')")
                 print "3 kolom tabel"
             elif nil==4:
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 db.execute("INSERT INTO "+namaT+" VALUES "+"('"+a+"','"+b+"','"+c+"','"+d+"')")
                 print "4 kolom tabel"
             elif nil==5:
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e=sb[4]
                 db.execute("INSERT INTO "+namaT+" VALUES "+"('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"')")
                 print "5 kolom tabel"
             elif nil==6:
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f=sb[4],sb[5]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?)",(a,b,c,d,e,f))
                 print "6 kolom tabel"
             elif nil==7:
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g=sb[4],sb[5],sb[6]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?)",(a,b,c,d,e,f,g))
                 print "7 kolom tabel"
             elif nil==8:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h))
                 print "8 kolom tabel"
             elif nil==9:
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i=sb[8]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i))
                 print "9 kolom tabel"
             elif nil==10:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text,j text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i,j=sb[8],sb[9]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j))
                 print "10 kolom tabel"
             elif nil==11:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text,j text,k text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i,j,k=sb[8],sb[9],sb[10]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j,k))
                 print "11 kolom tabel"
             elif nil==12:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text,j text,k text,l text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i,j,k,l=sb[8],sb[9],sb[10],sb[11]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j,k,l))
                 print "12 kolom tabel"
             elif nil==13:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text,j text,k text,l text,m text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i,j,k,l=sb[8],sb[9],sb[10],sb[11]
                 m=sb[12]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j,k,l,m))
                 print "13 kolom tabel"
             elif nil==14:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text,j text,k text,l text,m text,n text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i,j,k,l=sb[8],sb[9],sb[10],sb[11]
                 m,n=sb[12],sb[13]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j,k,l,m,n))
                 print "14 kolom tabel"
             elif nil==15:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text,j text,k text,l text,m text,n text,o text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i,j,k,l=sb[8],sb[9],sb[10],sb[11]
                 m,n,o=sb[12],sb[13],sb[14]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o))
                 print "15 kolom tabel"
             elif nil==16:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text,j text,k text,l text,m text,n text,o text,p text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i,j,k,l=sb[8],sb[9],sb[10],sb[11]
                 m,n,o=sb[12],sb[13],sb[14]
                 p=sb[15]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p))
                 print "16 kolom tabel"
             elif nil==17:
                 print "Nilai ",nil
                 db.execute("CREATE TABLE "+namaT+"(a text,b text,c text,d text,e text,f text,g text,h text,i text,j text,k text,l text,m text,n text,o text,p text)")
                 a,b,c,d=sb[0],sb[1],sb[2],sb[3]
                 e,f,g,h=sb[4],sb[5],sb[6],sb[7]
                 i,j,k,l=sb[8],sb[9],sb[10],sb[11]
                 m,n,o=sb[12],sb[13],sb[14]
                 p,q=sb[15],sb[16]
                 db.execute("INSERT INTO "+namaT+" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q))
                 print "17 kolom tabel"
           else:
              print "Tabel ",namaT," Gagal dibuat"
        con.commit()
        con.close()

