#!/usr/bin/env python
class Tambah:
   def __init__(self):
          import sqlite3
          con=sqlite3.connect("data.db")
          db=con.cursor()
          namaTabel=raw_input("Nama tabel : \t")
          namaB=raw_input("Nama barang : \t")
          hargaB=raw_input("Harga barang : \t")
          jumlahB=raw_input("Jumlah barang : \t")
          cekDb=db.execute("INSERT INTO "+namaTabel+" VALUES(?,?,?)",(namaB,hargaB,jumlahB))
          if cekDb:
            print "Sudah ditambahkan"
          else:
            print "Gagal ditambahkan"
          con.commit()
          con.close()

