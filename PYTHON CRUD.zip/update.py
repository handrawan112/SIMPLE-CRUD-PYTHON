#!/usr/bin/env python
import sqlite3
class Perbarui:
  def  __init__(self):
          con=sqlite3.connect("data.db")
          db=con.cursor()
          namaDb=raw_input("Nama tabel database : \t")
          namaB=raw_input("Nama barang :\t")
          hargaB=raw_input("Harga barang :\t")
          jumlahB=raw_input("Jumlah barang :\t")
          cekDb=db.execute("UPDATE "+namaDb+" SET hargaBarang="+"'"+hargaB+"'"+",jumlahBarang="+"'"+jumlahB+"'"+" WHERE namaBarang="+"'"+namaB+"'")
          if cekDb:
             print "Berhasil di update"
          else:
             print "Gagal di update"
          con.commit()
          con.close()

